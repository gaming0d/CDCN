import TableStudent from './tableStudent';
import './App.css';

function App() {
  return (
    <div className="App">
      <TableStudent />
    </div>
  );
}

export default App;
