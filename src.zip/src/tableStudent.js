import React, { useState } from "react";
import data from "./data.json";
import { FaTrash } from "react-icons/fa";
import { AiFillTool } from "react-icons/ai";
import "./tableStudent.css";

const DataDisplay = () => {
  const [items, setItems] = useState(data);
  const [editingIndex, setEditingIndex] = useState(-1);
  const [nameInput, setNameInput] = useState("");
  const [mssvInput, setMssvInput] = useState("");
  const [birthdayInput, setBirthdayInput] = useState("");
  const [countryInput, setCountryInput] = useState("");

  const [newItem, setNewItem] = useState({
    name: "",
    mssv: "",
    birthday: "",
    country: "",
  });

  const renderTableData = () => {
    return (
      <>
        {items.map((item, index) => {
          const { name, mssv, birthday, country } = item;
          return (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>
                {editingIndex === index ? (
                  <input
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                  />
                ) : (
                  name
                )}
              </td>
              {/* <td>{editingIndex === index ? <input value={mssvInput} onChange={e => setMssvInput(e.target.value)} /> : mssv}</td> */}
              <td>{mssv}</td>
              <td>
                {editingIndex === index ? (
                  <input
                    value={birthdayInput}
                    onChange={(e) => setBirthdayInput(e.target.value)}
                  />
                ) : (
                  birthday
                )}
              </td>
              <td>
                {editingIndex === index ? (
                  <input
                    value={countryInput}
                    onChange={(e) => setCountryInput(e.target.value)}
                  />
                ) : (
                  country
                )}
              </td>
              <td>
                {editingIndex === index ? (
                  <button onClick={() => handleSubmit(index)}>Save</button>
                ) : (
                  <AiFillTool onClick={() => handleEdit(index, item)} />
                )}
              </td>
              <td>
                <FaTrash onClick={() => handleDelete(index)} />
              </td>
            </tr>
          );
        })}

        <tr>
          <td>#</td>
          <td>
            <input
              value={newItem.name}
              onChange={(e) => handleNewInputChange(e, "name")}
            />
          </td>
          <td>
            <input
              value={newItem.mssv}
              onChange={(e) => handleNewInputChange(e, "mssv")}
            />
          </td>
          <td>
            <input
              value={newItem.birthday}
              onChange={(e) => handleNewInputChange(e, "birthday")}
            />
          </td>
          <td>
            <input
              value={newItem.country}
              onChange={(e) => handleNewInputChange(e, "country")}
            />
          </td>
          <td>
            <button onClick={handleAddNewItem}>Add</button>
          </td>
          <td></td>
        </tr>
      </>
    );
  };


  function Pair(first, second) {
    this.first = first;
    this.second = second;
  }

  const NameCountry = [];
  const handleAddNewItem = () => {
    if (!validateInput(newItem.name) || !validateInput(newItem.mssv) || !validateInput(newItem.birthday) || !validateInput(newItem.country)) {
      alert("Please fill in all fields");
      return;
    }
    if (validateInputMssv(newItem.mssv) === 2) {
      alert("MSSV phai chua 8 chu so");
      return;
    }
    if (validateInputMssv(newItem.mssv) === 1) {
      alert("MSSV da ton tai");
      return;
    }
    if (!validateBirthday(newItem.birthday)) {
      alert("Sai dinh dang ngay sinh");
      return;
    }
    const temp = new Pair(newItem.name.input, newItem.name.country);
    if (NameCountry.includes(temp)) {
      alert("Ten va que quan da ton tai");
      return;
    }
    NameCountry.push(temp);
    setItems((prevItems) => [...prevItems, newItem]);
    setNewItem({ name: "", mssv: "", birthday: "", country: "" });
  };

  const validateInput = (input, field) => {
    if (input.trim() === "") {
      return false;
    }

    return true;
  };

  const MssvList = new Set();
  const validateInputMssv = (input, field) => {
    if (input.trim().length !== 8) {
      return 2;
    }
    alert(MssvList.has(input.trim()));
    if (MssvList.has(input.trim())) {
      return 1;
    }
    MssvList.add(input.trim());
    return 0;
  };

  const validateBirthday = (input, field) => {
    let parts = input.split("/");
    let day = parseInt(parts[0]);
    let month = parseInt(parts[1]) - 1;
    let year = parseInt(parts[2]);

    let date = new Date(year, month, day);

    if (date.getFullYear() === year && date.getMonth() === month && date.getDate() === day) {
      return true;
    } else {
      return false;
    }
  };

  const handleNewInputChange = (e, field) => {
    const value = e.target.value;
    setNewItem((prevItem) => ({ ...prevItem, [field]: value }));
  };

  const handleDelete = (index) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    setItems(newItems);
  };

  const handleEdit = (index, item) => {
    setEditingIndex(index);
    setNameInput(item.name);
    setMssvInput(item.mssv);
    setBirthdayInput(item.birthday);
    setCountryInput(item.country);
  };

  const handleSubmit = (index) => {
    const newItems = [...items];
    newItems[index] = {
      name: nameInput,
      mssv: mssvInput,
      birthday: birthdayInput,
      country: countryInput,
    };
    setItems(newItems);
    setEditingIndex(-1);
  };

  return (
    <div>
      <h2>Quản lý sinh viên</h2>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>MSSV</th>
            <th>Birthday</th>
            <th>Country</th>
            <th>Change</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>{renderTableData()}</tbody>
      </table>
    </div>
  );
};

export default DataDisplay;
